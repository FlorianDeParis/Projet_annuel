<?php
    session_start();
	include_once './lib/param.php';
 
    //On inclut le contrôleur s'il existe et s'il est spécifié
	/*
		if (!empty($_GET['page']) && is_file('controller/'.$_GET['page'].'.php')){
			include 'controller/'.$_GET['page'].'.php';
		}
	*/
?>


<!--TEST-->
<?php
	echo get_head();
?>
<!--TEST2-->
	
	<header class="header">
	    <p>en tete</p>
	</header>
	
	<nav class="nav">
	    <p>menu</p>
	</nav>

	<div id="body" class="body"> 
		<h1>body</h1>
			<?php
				// pour exemple
				echo get_table_genre();
			?>

		<?php
		
		function get_form_genre($id_genre){
	
			if($id_genre > 0){
				//alors c'est une modification 
				
				// -------------- une fonction devrait faire cela debut --------------					
					$req_genre = "SELECT * FROM `genre_use` WHERE `id_genre_use` = ".$id_genre;
					
					
					$db = new connexion();
					//a activé je ne suis pas connecter a une bdd
					//$a_res = $db->pdo_sql_array_assoc($req_genre);
				// -------------- une fonction devrait faire cela fin --------------	

				
				$s_libel = $a_res['libel_genre_use'];
				$button = button('modifier', 'newGenre("form_genre");');

			}
			else{
				//alors c'est un nouveaux
				$s_libel = '';
				
				$button = button('nouveau', 'newGenre("form_genre");');
			}
										
			$html = '';
			$genre_user = array('Id genre'
						,'Libele genre');
				
			$html .= '
					<div style="margin-left: 300px;">
						<form class="formulaire" id="form_genre">
								<table class="tableau">
									<tr>
										<td style="width:120px;">Libele genre</td>
									</tr>			
									<tr>
										<td style="width:120px;">
											'.input_txt('libel_genre',$s_libel,'Genre Utilisateur','',0).'
										</td>									
									</tr>
									<tr>
										<td style="width:120px;">
											'.button('annuler', '').'
											'.$button.'
										</td>	
									</tr>
										
								</table>
						</form>
					</div>';
						
			return $html;
			}
		
		
		
		
		
		
		
		?>







		</div>
		
<?php
	echo get_foot();
?>

