<?php

/**
 * @author AdrienSY
 */

function autoloader($classe)
{
	$repertoires = array(
			"Mod�les" => __DIR__."/../modele/",
			"Contr�leurs" => __DIR__."/../controller/"
	);
	$i = 0;
	foreach ($repertoires as $repertoire)
	{
		$i++;
		if (@include_once($repertoire.strtolower($classe)."_class.php")) return true;
		
		echo $i;
		if($i == 300){
			exit();
		}
	}
	
	return false;
}

spl_autoload_register("autoloader");