<?php
    //fonction anonyme autoload
    spl_autoload_register(function ($class) {
        include 'modeles/' . $class . '._class.php';
    });
	
    function get_head(){
		$html ='
        <!DOCTYPE html>
        <html style="width: 1400px; margin:0px;">
            <head>
                <meta charset="utf-8" />
                <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
                <title>Titre</title>
            </head>
            <body>';
		return $html;
	}
	
	/**
	 * Message reussite
	 * @param string $message
	 */
	function getMessageOk($message)
	{
		$sHtml = "";
		
		$sHtml .= "<div id=\"msg_ok\">";
		$sHtml .= "R�ussite!<br />";
		$sHtml .= $message;
		$sHtml .= "</div>";
		
		return $sHtml;
	}
	
	/**
	 * Message echec
	 * @param array $message
	 */
	function getMessageKo($aMessages)
	{
		$sHtml = "";
		
		$sHtml .= "<div id=\"msg_ko\">";
		$sHtml .= "�chec!";
		
		$sHtml .= "<table>";
		
		foreach ($aMessages as $message)
		{
			$sHtml .= "<tr>";
			$sHtml .= "<td>- ";
			$sHtml .= $message;
			$sHtml .= "</td>";
			$sHtml .= "</tr>";
		}
		
		$sHtml .= "</table>";
		
		$sHtml .= "</div>";
		
		return $sHtml;
	}
	
	function get_foot(){
		$html ='
		        <footer style="border: 1px black solid;width: 1400px;height: 100px;margin-left: 10px;">
			        <p>pied</p>
			    </footer>
		    </body>
		</html>
        ';
        
		return $html;
	}
    
    function input_txt($name,$value,$label,$classe,$br) {
		$html = '';
        
        if ($label != 'null') {
            if (!empty($label)) { $sep = ' :'; } else { $sep = '  '; }
            $html.= '<label class="'.$classe.'" for="'.$name.'">'.$label.$sep.'</label>';
        }

		$html.= '<input type="text" name="'.$name.'" value="'.$value.'" />';
        if ($br==1) { $html.= '<br />'; }
        
		
		return $html;
	}
	
	function input_pwd($name,$value,$label,$classe,$br) {
		$html = '';
		
        if ($label != 'null') {
            if (!empty($label)) { $sep = ' :'; } else { $sep = '  '; }
            $html.= '<label class="'.$classe.'" for="'.$name.'">'.$label.$sep.'</label>';
        }
        
		$html.= '<input type="password" name="'.$name.'" value="'.$value.'" />';
		
        if ($br==1) { $html.= '<br />'; }
		
		return $html;
	}
	
	function input_hidden($name,$value,$label,$classe,$br) {
		$html = '';
        
        if ($label != 'null') {
            if (!empty($label)) { $sep = ' :'; } else { $sep = '  '; }
            $html.= '<label class="'.$classe.'" for="'.$name.'">'.$label.$sep.'</label>';
        }
        
		$html.= '<input type="hidden" name="'.$name.'" value="'.$value.'" />';
        
        if ($br==1) { $html.= '<br />'; }
        
		return $html;
	}
	
	function textArea($name,$value,$label,$classe,$br) {
		$html = '';
		
        if ($label != 'null') {
            if (!empty($label)) { $sep = ' :'; } else { $sep = '  '; }
            $html.= '<label class="'.$classe.'" for="'.$name.'">'.$label.$sep.'</label>';
        }
        
		$html.= '<textarea name="'.$name.'" rows="8" cols="45">'.$value.'</textarea>';
		
        if ($br==1) { $html.= '<br />'; }
		
		return $html;
	}
	
	function get_table_genre(){
	
		$genre_user = array('Id genre'
							,'Libele genre');
		
	// -------------- une fonction devrait faire cela debut --------------					
		$req_genre = "SELECT * FROM `genre_use`";
		
		
		$db = new connexion();
		//a activ� je ne suis pas connecter a une bdd
		//$a_res = $db->pdo_sql_array_assoc($req_genre);
	// -------------- une fonction devrai faire cela fin --------------	
		
		
		
		$a_res = array();


		$html2 = '';
		$html = '';
		foreach($a_res as $key => $val){
			$html2 .= '<tr>
						<td>'.$val->id_genre_use.'</td>
						<td>'.$val->libel_genre_use.'</td>
						<td class="i_toolbar"><i class="fa fa-pencil i_hover" onclick=""/></i></td>
						<td class="i_toolbar"><i class="fa fa-times i_hover" onclick=""/></i></td>
					</tr>';
		
		}
	
		$html .= '
				<div style="margin-left: 300px;">
					<table class="tableau">
						<tr>';
						foreach($genre_user as $value){
							$html .= '<td style="width:120px;">'.$value.'</td>';
						}
				$html .= '	<td ></td>
							<td class="i_toolbar"><i class="fa fa-plus-circle i_hover" /></i></td>
						</tr>			
					'.$html2.'
				</table>
			</div>';
			
		
		return $html;
	
	}
	
	//prototype, pense a passer le id du formulaire avec la fonction en parametre
	function button($type, $fonction){
			$html = '';
			$js = '';
			
			switch($type){
				case 'valider' :
						$html .= '<input id="form_bt_val" type="button" class="bt_btn" name="Enregistrer">';
						$js .= "$('#form_bt_val').click( function() { 
									".$fonction_js."
								});
								";
					break;
					
				case 'modifier' :
						$html .= '<input id="form_bt_val" type="button" class="bt_btn" name="Enregistrer">';
						$js .= "$('#form_bt_val').click( function() { 
									".$fonction_js."
								});
								";
					break;
					
				case 'nouveau' :
						$html .= '<input id="form_bt_val" type="button" class="bt_btn" name="Enregistrer">';
						$js .= "$('#form_bt_val').click( function() { 
									".$fonction_js."
								});
								";
					break;
					
				case 'annuler' :
						$html .= '<input id="form_bt_ann" type="button" class="bt_btn" name="Annuler">';
						$js .= "$('#form_bt_ann').click( function() { 
									".$fonction_js."
								});
								";
					break;
					
				case 'supprimer' :
						$html .= '<input id="form_bt_sup" type="button" class="bt_btn" name="Supprimer">';
						$js .= "$('#form_bt_sup').click( function() { 
									".$fonction_js."
								});
								";
					break;
			}
			
			$html .= '<script>
							'.$js.'
						</script>';
			 
			
			return $html;
		}

	
	
?>