<?php

//declaration des constantes
// Constante de la racine du site. A changer en production
const RACINE_SITE = "http://127.0.0.1/Projet_annuel/index.php";
	
	include_once ('autoloader.php');
	include_once('fonc_fun.php');
	include_once('./css/all_css.css');
	//include_once(__DIR__.'/../_js/');

?>